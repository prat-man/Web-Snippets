var app = angular.module('hover-effects',[]);

app.controller('hover-effects-main', function($scope) {
	$scope.entryList =['Hello', 'World'];
});